import React from 'react';
import { createRoot } from 'react-dom/client';
import { motion } from 'framer-motion';
import {
  ArrowUpRight,
  BrainCircuit,
  Briefcase,
  Code2,
  Database,
  Download,
  GitBranch,
  Layers3,
  Mail,
  MapPin,
  Phone,
  Rocket,
  Server,
  Sparkles,
  Workflow,
} from 'lucide-react';
import './styles.css';

const profile = {
  name: 'Deepak Mudili',
  title: 'Python GenAI Engineer | FastAPI | RAG | LangChain | LLM Applications',
  phone: '+91 9110721434',
  email: 'Deepakmudilli@gmail.com',
  location: 'India',
  resume: './Deepak_Mudili_Resume.pdf',
  live: 'https://ai-hiring-53c18c.netlify.app/index.html',
  github: 'https://github.com/DeepakMudili/ai-hiring-decision-engine',
};

const skillGroups = [
  ['Languages', ['Python', 'SQL', 'JavaScript']],
  ['GenAI / LLM', ['LangChain', 'OpenAI API', 'Groq API', 'Llama 3.1', 'RAG', 'Prompt Engineering', 'Vector Embeddings', 'Semantic Search']],
  ['Backend', ['FastAPI', 'REST APIs', 'Microservices', 'JWT Authentication', 'Swagger/OpenAPI']],
  ['Databases & Vector DB', ['PostgreSQL', 'SQL Server', 'ChromaDB', 'FAISS', 'SQLite', 'Supabase']],
  ['AI & Data', ['PyMuPDF', 'Resume Parsing', 'PDF Processing', 'Pandas', 'Data Validation', 'APScheduler']],
  ['Cloud & DevOps', ['Git', 'GitHub', 'Render', 'Netlify', 'Environment Variables']],
];

const projects = [
  {
    title: 'AI Hiring Intelligence Platform',
    type: 'Python / GenAI',
    icon: BrainCircuit,
    stack: ['Python', 'FastAPI', 'LangChain', 'RAG', 'Groq API', 'Llama 3.1', 'ChromaDB', 'Supabase PostgreSQL', 'PyMuPDF'],
    summary: 'AI-powered hiring platform for resume analysis, recruiter workflows, candidate ranking, semantic search, and hiring analytics.',
    highlights: [
      'Implemented RAG pipelines using LangChain, ChromaDB, vector embeddings, and semantic retrieval.',
      'Integrated Groq API / Llama 3.1 for candidate scores, matched skills, missing skills, feedback summaries, and interview questions.',
      'Designed FastAPI REST endpoints for login, job posting, resume upload, recruiter copilot, analytics, and hiring decisions.',
      'Parsed resumes using PyMuPDF and stored user, job, application, score, and resume data in Supabase PostgreSQL.',
    ],
    live: 'https://ai-hiring-53c18c.netlify.app/index.html',
    github: 'https://github.com/DeepakMudili/ai-hiring-decision-engine',
  },
  {
    title: 'PwC Customer Data Management System',
    type: 'Python Backend',
    icon: Server,
    stack: ['Python', 'FastAPI', 'REST APIs', 'JWT Authentication', 'SQL Server', 'Swagger/OpenAPI', 'Infomaker'],
    summary: 'Python backend project for enterprise customer data management, CRUD workflows, API security, SQL optimization, and reporting support.',
    highlights: [
      'Developed and maintained FastAPI services for enterprise customer data management and CRUD workflows.',
      'Secured APIs using JWT authentication and CORS policies; integrated frontend applications with backend services.',
      'Optimized SQL Server queries, joins, indexes, and stored procedures for high-volume data processing.',
      'Created reporting workflows using Infomaker and supported API validation through Swagger/OpenAPI.',
    ],
  },
  {
    title: 'AI Meeting Assistant',
    type: 'Python / GenAI',
    icon: Workflow,
    stack: ['Python', 'FastAPI', 'LangChain', 'OpenAI API', 'RAG', 'FAISS', 'SQLite', 'APScheduler'],
    summary: 'FastAPI application for meeting scheduling, notes management, AI summaries, action item extraction, reminders, and semantic note retrieval.',
    highlights: [
      'Built a FastAPI application for meeting scheduling, notes management, and automated reminders using APScheduler.',
      'Integrated LangChain + OpenAI API to summarize meeting notes and extract action items automatically.',
      'Implemented semantic search using OpenAI embeddings + FAISS to retrieve relevant notes across sessions.',
    ],
  },
];

const architecture = [
  ['Frontend', 'React / Netlify portfolio and application UI for recruiter-facing workflows.'],
  ['Backend APIs', 'FastAPI REST endpoints for authentication, resume upload, analytics, and AI workflows.'],
  ['GenAI Layer', 'LangChain, RAG, OpenAI/Groq, prompt engineering, and structured AI outputs.'],
  ['Vector Search', 'ChromaDB / FAISS with embeddings for semantic retrieval and candidate matching.'],
  ['Data Layer', 'PostgreSQL, SQL Server, Supabase, and SQLite for structured data storage.'],
];

function Badge({ children }) {
  return <span className="badge">{children}</span>;
}

function SectionHeader({ label, title, text }) {
  return (
    <div className="section-header">
      <p>{label}</p>
      <h2>{title}</h2>
      {text && <span>{text}</span>}
    </div>
  );
}

function App() {
  return (
    <main>
      <section className="hero" id="home">
        <div className="glow glow-one" />
        <div className="glow glow-two" />
        <nav>
          <strong>{profile.name}</strong>
          <div>
            <a href="#projects">Projects</a>
            <a href="#skills">Skills</a>
            <a href="#contact">Contact</a>
          </div>
        </nav>

        <div className="hero-grid">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="eyebrow"><Sparkles size={16} /> Python GenAI Engineer</div>
            <h1>Building AI-powered applications with FastAPI, RAG, and LangChain.</h1>
            <p className="hero-copy">
              I build backend-first GenAI applications with REST APIs, vector embeddings, semantic search, resume parsing, recruiter copilots, and cloud deployment.
            </p>
            <div className="contact-row">
              <span><Phone size={16} /> {profile.phone}</span>
              <span><Mail size={16} /> {profile.email}</span>
              <span><MapPin size={16} /> {profile.location}</span>
            </div>
            <div className="actions">
              <a className="btn primary" href={profile.resume} download><Download size={18} /> Download Resume</a>
              <a className="btn" href={profile.live} target="_blank" rel="noreferrer"><ArrowUpRight size={18} /> Live Project</a>
              <a className="btn" href={profile.github} target="_blank" rel="noreferrer"><GitBranch size={18} /> GitHub</a>
            </div>
          </motion.div>

          <motion.div className="hero-card" initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, delay: 0.1 }}>
            <BrainCircuit size={42} />
            <h3>Core Focus</h3>
            <ul>
              <li>RAG pipelines and LLM integrations</li>
              <li>FastAPI microservices and REST APIs</li>
              <li>Semantic search with ChromaDB / FAISS</li>
              <li>Resume parsing and recruiter intelligence workflows</li>
            </ul>
          </motion.div>
        </div>
      </section>

      <section className="section" id="skills">
        <SectionHeader label="Technical Stack" title="Hot Skills for GenAI Backend Roles" text="Focused on the skills most relevant to Python GenAI, RAG, FastAPI, and AI backend roles." />
        <div className="skills-grid">
          {skillGroups.map(([title, items], index) => (
            <motion.div className="card" key={title} initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.04 }}>
              <h3>{title}</h3>
              <div className="badges">{items.map((item) => <Badge key={item}>{item}</Badge>)}</div>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="section" id="experience">
        <SectionHeader label="Experience" title="LTIMindtree — Software Developer" text="March 2024 – Present | India" />
        <div className="timeline-card">
          <ul>
            <li>Engineered Python FastAPI microservices, REST API workflows, and GenAI integrations supporting enterprise data and application workflows.</li>
            <li>Built and optimized RAG pipelines using LangChain, vector embeddings, and semantic retrieval for context-aware AI response generation.</li>
            <li>Resolved API, database, and application issues by analyzing logs, validating SQL queries, testing endpoints, and coordinating fixes.</li>
            <li>Partnered with cross-functional teams across SDLC, Agile delivery, sprint planning, testing, and deployment validation.</li>
            <li>Improved application stability and delivery quality through unit testing, API testing, debugging, and peer code reviews.</li>
          </ul>
        </div>
      </section>

      <section className="section" id="projects">
        <SectionHeader label="Featured Projects" title="Projects Built Around Python, GenAI, and Backend Systems" />
        <div className="project-grid">
          {projects.map((project) => {
            const Icon = project.icon;
            return (
              <motion.article className="project-card" key={project.title} initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
                <div className="project-top">
                  <div className="project-icon"><Icon size={24} /></div>
                  <div>
                    <p>{project.type}</p>
                    <h3>{project.title}</h3>
                  </div>
                </div>
                <p className="summary">{project.summary}</p>
                <div className="badges">{project.stack.map((item) => <Badge key={item}>{item}</Badge>)}</div>
                <ul>{project.highlights.map((item) => <li key={item}>{item}</li>)}</ul>
                <div className="project-links">
                  {project.live && <a href={project.live} target="_blank" rel="noreferrer">Live Demo <ArrowUpRight size={15} /></a>}
                  {project.github && <a href={project.github} target="_blank" rel="noreferrer">GitHub <GitBranch size={15} /></a>}
                </div>
              </motion.article>
            );
          })}
        </div>
      </section>

      <section className="section">
        <SectionHeader label="Architecture" title="How My AI Applications Are Designed" text="A simple high-level view of the systems I build and explain in interviews." />
        <div className="architecture">
          {architecture.map(([title, text], index) => (
            <div className="arch-step" key={title}>
              <span>{String(index + 1).padStart(2, '0')}</span>
              <h3>{title}</h3>
              <p>{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section certs">
        <SectionHeader label="Certifications" title="Learning & Credentials" />
        <div className="cert-grid">
          <div className="card"><ShieldCheckIcon /> <h3>Microsoft Certified: Azure AI Fundamentals</h3><p>AI-900 | 2023</p></div>
          <div className="card"><ShieldCheckIcon /> <h3>Ignite Certification</h3><p>LTIMindtree Batch 1 | 2023</p></div>
          <div className="card"><ShieldCheckIcon /> <h3>Introduction to LangChain — Python</h3><p>LangChain Academy | 2026</p></div>
          <div className="card"><ShieldCheckIcon /> <h3>Introduction to LangGraph — Python</h3><p>LangChain Academy | 2026</p></div>
        </div>
      </section>

      <section className="contact" id="contact">
        <Layers3 size={38} />
        <h2>Open to Python GenAI, RAG, FastAPI, and AI Backend roles.</h2>
        <p>Let’s connect for AI application engineering, backend systems, RAG workflows, and LLM-powered product roles.</p>
        <div className="actions centered">
          <a className="btn primary" href={`mailto:${profile.email}`}><Mail size={18} /> Email Me</a>
          <a className="btn" href={profile.resume} download><Download size={18} /> Resume</a>
          <a className="btn" href={profile.github} target="_blank" rel="noreferrer"><GitBranch size={18} /> GitHub</a>
        </div>
      </section>
    </main>
  );
}

function ShieldCheckIcon() {
  return <Rocket size={26} className="cert-icon" />;
}

createRoot(document.getElementById('root')).render(<App />);
